const catchAsyncError = require("../../middleware/catchAsyncError");
const Appointment = require("../Appointment/appointment.model");
const { calculateSlots } = require("../../utils/calculateSlots"); // Assuming the calculateSlots function is in a separate file

exports.getSlots = catchAsyncError(async (req, res) => {
  const { doctorId, selectedDate } = req.query;

  try {
    const appointment = await Appointment.findOne({
      doctorId,
      selectedDates: selectedDate,
    }).exec();

    if (!appointment) {
      return res.status(404).json({ error: "Appointment not found" });
    }

    const slots = calculateSlots(
      appointment.startTime,
      appointment.endTime,
      appointment.duration
    );

    res.status(200).json(slots);
  } catch (error) {
    console.error("Error retrieving slots:", error);
    res.status(500).json({ error: "An error occurred" });
  }
});
