const express = require("express");
const { getSlots } = require("./slots.controller");

const router = express.Router();

router.route("/slots").get(getSlots);

module.exports = router;