const mongoose = require("mongoose");
const { ObjectId } = mongoose.Schema.Types;

const appointmentSchema = new mongoose.Schema({
  doctorId: {
    type: ObjectId,
    ref: "Doctor",
  },
  selectedDate: {
    type: Date,
    required: true,
  },
});

module.exports = mongoose.model("Appointment", appointmentSchema);
